#steps :

```

conda create -p myenv python==3.10 
conda activate ./myenv 
conda env list

doskey /history

streamlit run main.py

pip install faiss-cpu==1.7.4 torch==2.1.2
  512  python --version
  513  pip install -r requirements.txt
  514  pip install --upgrade pip setuptools wheel ( if required)
  515  python -m pip install --upgrade pip setuptools wheel ( if required)
than agn :
  517  pip install -r requirements.txt

streamlit run main.py

------------------------------------------


We are all set 👍🏼 Let's ask some questions now :
- Do you provide job assistance and also do you provide job gurantee?
- Do you provide any javascript course?'
- Do you provide emi options?
As you can see above, the answer of question comes from two different FAQs within our csv file and it is able to pull those questions and merge them nicely

- Do you have plans to launch blockchain course in future?
- should I learn power bi or tableau?
- who is apj abdul kalam ?
- I've a MAC computer. Can I use powerbi on it?

----------------------------------------------



--- when app is running and we want a stricter app which confines to onlythe knowlege database , update the prompt template in langchain_helper.py :

prompt_template = """Given the following context and a question, generate an answer based on this context only.
    In the answer try to provide as much text as possible from "response" section in the source document context without making much changes.
    If the answer is not found in the context, kindly state "I don't know." Don't try to make up an answer.

    CONTEXT: {context}

    QUESTION: {question}"""



===========================================


```























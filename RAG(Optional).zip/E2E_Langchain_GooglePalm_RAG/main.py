import os
import streamlit as st
from langchain_helper import get_qa_chain, create_vector_db
from dotenv import load_dotenv

# Load .env variables
load_dotenv()

st.set_page_config(page_title="xyz Q&A", page_icon="🌱")
st.title("xyz Q&A 🌱")

# Validate API Key
if not os.getenv("GOOGLE_API_KEY"):
    st.error("Missing Google API key! Please set GOOGLE_API_KEY in your .env file.")
    st.stop()

# Create knowledge base
if st.button("Create Knowledgebase"):
    with st.spinner("Creating vector database..."):
        create_vector_db()
    st.success("Knowledgebase created successfully!")

# Input box for user question
question = st.text_input("Ask a question from the knowledgebase:")

# Cache the chain to avoid repeated DB loading
@st.cache_resource
def load_chain():
    return get_qa_chain()

# Process the question
if question:
    chain = load_chain()
    response = chain(question)

    st.header("Answer")
    st.write(response["result"])

import os
from dotenv import load_dotenv
from langchain.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.document_loaders.csv_loader import CSVLoader
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA

load_dotenv()

# Set embedding model
embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

# Vector DB location
vectordb_file_path = "faiss_index"

# Initialize LLM (Gemini 1.5 Pro)/ gemini-1.5-flash
llm = ChatGoogleGenerativeAI(
    model="models/gemini-1.5-flash",  
    #model="models/text-bison-001",
    temperature=0.7,
    google_api_key=os.environ["GOOGLE_API_KEY"],
    convert_system_message_to_human=True
)

def create_vector_db():
    loader = CSVLoader(file_path='xyz_faqs.csv', source_column="prompt")
    documents = loader.load()

    vectordb = FAISS.from_documents(documents=documents, embedding=embedding_model)
    vectordb.save_local(vectordb_file_path)

def get_qa_chain():
    vectordb = FAISS.load_local(vectordb_file_path, embedding_model, allow_dangerous_deserialization=True)
    retriever = vectordb.as_retriever(score_threshold=0.7)

    prompt_template = """You are a helpful assistant. Given the context below, answer the user's question.

- If the context contains a relevant answer in the "response" part, answer using that only.
- If the context does NOT contain an answer,kindly state "I don't know", politely inform the user that the information is not found in the KNOWLEDGE BASE , but then provide a helpful and complete answer using your general knowledge.
- MAKE SURE  u mention STRICTLY AND CLEARLY about information not found in knowledge base anyhow proving general information as per internet.
CONTEXT: {context}

QUESTION: {question}
"""

    prompt = PromptTemplate(template=prompt_template, input_variables=["context", "question"])

    chain = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        chain_type="stuff",
        input_key="query",
        return_source_documents=True,
        chain_type_kwargs={"prompt": prompt}
    )

    return chain

if __name__ == "__main__":
    create_vector_db()
    chain = get_qa_chain()
    print(chain("Do you have javascript course?"))
